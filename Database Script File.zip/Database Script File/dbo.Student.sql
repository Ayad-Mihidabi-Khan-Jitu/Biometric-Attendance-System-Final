﻿CREATE TABLE [dbo].[Student] (
    [Serial]                 INT           IDENTITY (1, 1) NOT NULL,
    [Student_ID]             NCHAR (10)    NOT NULL,
    [Student_Name]           VARCHAR (50)  NOT NULL,
    [Student_Reg]            NCHAR (10)    NOT NULL,
    [Student_Session]        NCHAR (10)    NOT NULL,
    [Student_Semester]       NCHAR (10)    NOT NULL,
    [Student_Email]          NVARCHAR (50) NULL,
    [Student_Photo]          IMAGE         NULL,
    [Student_Fingerprint_ID] INT           NULL,
    [Student_Faculty]        NVARCHAR (50) NULL,
    CONSTRAINT [STUDENT_ID_UNIQUE] UNIQUE NONCLUSTERED ([Student_ID] ASC)
);


GO
CREATE TRIGGER trg_insert_Student
  ON Student
  AFTER INSERT
  AS 
  BEGIN
	SET NOCOUNT ON
	INSERT INTO FingerprintID(FingerPrintID) 
	SELECT i.Student_Fingerprint_ID
	FROM inserted i
  END
GO
  CREATE TRIGGER trg_delete_Student
  ON Student
  FOR DELETE
  AS DECLARE @fid INT
  BEGIN
	SET NOCOUNT ON
	SELECT @fid = del.Student_Fingerprint_ID FROM DELETED del;
	DELETE FROM FingerprintID WHERE FingerPrintID = @fid;
  END