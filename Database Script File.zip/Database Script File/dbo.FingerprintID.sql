﻿CREATE TABLE [dbo].[FingerprintID] (
    [FingerPrintID] INT NOT NULL,
    CONSTRAINT [PK_FingerprintID] PRIMARY KEY CLUSTERED ([FingerPrintID] ASC)
);

