﻿CREATE TABLE [dbo].[Teacher] (
    [Serial]                 INT           IDENTITY (1, 1) NOT NULL,
    [Teacher_Name]           NVARCHAR (50) NOT NULL,
    [Teacher_Department]     NVARCHAR (50) NOT NULL,
    [Teacher_Email]          NVARCHAR (50) NOT NULL,
    [Teacher_Mobile]         NCHAR (11)    NULL,
    [Password]               NCHAR (10)    NOT NULL,
    [Role]                   NCHAR (10)    NULL,
    [Photo]                  IMAGE         NULL,
    [Teacher_Faculty]        NVARCHAR (50) NULL,
    [Teacher_Fingerprint_ID] INT           NULL
);


GO
 CREATE TRIGGER trg_insert_Teacher
  ON Teacher AFTER INSERT
  AS 
  BEGIN
	SET NOCOUNT ON
	INSERT INTO FingerprintID(FingerPrintID) 
	SELECT i.Teacher_Fingerprint_ID
	FROM inserted i
  END
GO
CREATE TRIGGER trg_delete_Teacher
  ON Teacher
  FOR DELETE
  AS DECLARE @fid INT
  BEGIN
	SET NOCOUNT ON
	SELECT @fid = del.Teacher_Fingerprint_ID FROM DELETED del;
	DELETE FROM FingerprintID WHERE FingerPrintID = @fid;
  END