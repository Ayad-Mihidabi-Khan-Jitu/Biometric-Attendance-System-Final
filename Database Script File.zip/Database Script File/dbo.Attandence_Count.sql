﻿CREATE TABLE [dbo].[Attandence_Count] (
    [SL]              INT           IDENTITY (1, 1) NOT NULL,
    [Student_Name]    NVARCHAR (50) NULL,
    [Student_ID]      NCHAR (7)     NULL,
    [No_Attandence]   INT           NULL,
    [Attandence_Mark] INT           NULL
);

