﻿CREATE TABLE [dbo].[Faculty] (
    [Serial]       INT          IDENTITY (1, 1) NOT NULL,
    [Faculty_Name] VARCHAR (50) NOT NULL,
    CONSTRAINT [PK_Faculty] PRIMARY KEY CLUSTERED ([Serial] ASC)
);

