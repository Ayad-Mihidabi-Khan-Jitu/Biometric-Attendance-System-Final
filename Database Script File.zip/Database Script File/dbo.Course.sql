﻿CREATE TABLE [dbo].[Course] (
    [Serial]          INT           IDENTITY (1, 1) NOT NULL,
    [Course_Title]    NVARCHAR (50) NOT NULL,
    [Course_Code]     NVARCHAR (50) NOT NULL,
    [Credit_Hour]     FLOAT (53)    NULL,
    [Course_Semester] INT           NULL
);

