﻿CREATE TABLE [dbo].[Tbl_Person_Audit] (
    [Person_Name] VARCHAR (255) NOT NULL,
    [Gender]      VARCHAR (255) NULL,
    [City]        VARCHAR (255) NULL
);

