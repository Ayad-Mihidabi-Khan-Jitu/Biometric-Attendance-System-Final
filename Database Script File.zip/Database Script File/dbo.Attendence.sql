﻿CREATE TABLE [dbo].[Attendence] (
    [Serial]                 INT           IDENTITY (1, 1) NOT NULL,
    [Course_Code]            NVARCHAR (50) NOT NULL,
    [Course_Teacher]         NVARCHAR (50) NOT NULL,
    [Course_Teacher_Email]   NVARCHAR (50) NULL,
    [Student_ID]             NVARCHAR (50) NOT NULL,
    [Student_Name]           NVARCHAR (50) NULL,
    [Semester]               NVARCHAR (50) NOT NULL,
    [Class_No]               NVARCHAR (50) NULL,
    [Attendence_Status]      NVARCHAR (50) NULL,
    [Date]                   NVARCHAR (50) NULL,
    [Student_Fingerprint_ID] INT           NULL,
    CONSTRAINT [PK_Attendence] PRIMARY KEY CLUSTERED ([Serial] ASC)
);

