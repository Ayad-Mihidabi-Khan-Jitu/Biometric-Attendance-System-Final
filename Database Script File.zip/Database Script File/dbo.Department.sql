﻿CREATE TABLE [dbo].[Department] (
    [Serial]          INT           IDENTITY (1, 1) NOT NULL,
    [Department_Name] NVARCHAR (50) NOT NULL,
    CONSTRAINT [PK_Department] PRIMARY KEY CLUSTERED ([Serial] ASC)
);

